<?php 

$base_url = "../templates/ams/";
date_default_timezone_set("Asia/Singapore");

    ob_start();
    session_start();
    $user_code=$_SESSION['user_code'];
    $user_type=$_SESSION['user_type'];
    $customer_client_code = $_SESSION['user_customer_code'];
    $customer_id = $_SESSION['customer_id'];
    $customer_company_name = $_SESSION['customer_company_name'];
    $user_id = $_SESSION['user_id'];
    $user_role = $_SESSION['user_role'];
    $user_fname = $_SESSION['user_fname'];
    $user_email_id = $_SESSION['user_email_id'];


?>
<!DOCTYPE html>
<html lang="en">
<head>
	
	<!-- start: Meta -->
	<meta charset="utf-8">
	<title>AMS Next v1.0</title>
	<meta name="description" content="Ace Success Pte Ltd">
	<meta name="author" content="Mind Master">
	<meta name="keyword" content="Metro, Metro UI, Dashboard, Bootstrap, Admin, Template, Theme, Responsive, Fluid, Retina">
	<!-- end: Meta -->
	
	<!-- start: Mobile Specific -->
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- end: Mobile Specific -->
	
	<!-- start: CSS -->
	<link id="bootstrap-style" href=<?php echo $base_url."css/bootstrap.min.css"; ?> rel="stylesheet">
	<link href=<?php echo $base_url."css/bootstrap-responsive.min.css"; ?> rel="stylesheet">
	<link id="base-style" href=<?php echo $base_url."css/style.css"; ?> rel="stylesheet">
	<link id="base-style-responsive" href=<?php echo $base_url."css/style-responsive.css"; ?> rel="stylesheet">
	<link href='http://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800&subset=latin,cyrillic-ext,latin-ext' rel='stylesheet' type='text/css'>
	<!--
	<link rel="stylesheet" href="http://code.jquery.com/mobile/1.4.5/jquery.mobile-1.4.5.min.css">
	<script src="http://code.jquery.com/jquery-1.11.3.min.js"></script>
	<script src="http://code.jquery.com/mobile/1.4.5/jquery.mobile-1.4.5.min.js"></script>-->
	
	<!-- end: CSS -->
	

	<!-- The HTML5 shim, for IE6-8 support of HTML5 elements -->
	<!--[if lt IE 9]>
	  	<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
		<link id="ie-style" href="css/ie.css" rel="stylesheet">
	<![endif]-->
	
	<!--[if IE 9]>
		<link id="ie9style" href="css/ie9.css" rel="stylesheet">
	<![endif]-->
		
	<!-- start: Favicon -->
	<link rel="shortcut icon" href= href=<?php echo $base_url."img/favicon.ico"; ?> >
	<!-- end: Favicon -->
	
		
		
		
</head>
<body>