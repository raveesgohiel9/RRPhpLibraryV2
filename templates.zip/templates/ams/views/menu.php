<?php
$base_url = "http://www.ace-success.com.sg/dashboard/";
?>
			<!-- start: Main Menu -->
			<div id="sidebar-left" class="span2">
				<div class="nav-collapse sidebar-nav">
					<ul class="nav nav-tabs nav-stacked main-menu">
					<?php
					if(strcmp($_SESSION['user_type'],"Super Admin")==0)
					{
                                            echo '<li><a href="index.php"><i class="icon-dashboard"></i><span class="hidden-tablet"> Dashboard</span></a></li>
                                                    <li><a href="customerscontroller.php?module=Customers"><i class="icon-briefcase"></i><span class="hidden-tablet"> Customers</span></a></li>
                                                    <li><a href="userscontroller.php?action=Customer_user"><i class="icon-user"></i><span class="hidden-tablet"> Customer Users</span></a></li>
                                                    <!--<li><a href="invoices.html"><i class="icon-file"></i><span class="hidden-tablet"> Invoices</span></a></li>-->
                                                    <li><a href="userscontroller.php"><i class="icon-user"></i><span class="hidden-tablet"> Users</span></a></li>
                                                    <li><a href="paymentscontroller.php"><i class="icon-check"></i><span class="hidden-tablet">Invoice & Payments</span></a></li>
                                                    <li><a href="servicescontroller.php"><i class="icon-tasks"></i><span class="hidden-tablet"> Services</span></a></li>
                                                    <!--<li><a href="folderscontroller.php"><i class="icon-tasks"></i><span class="hidden-tablet"> Folders</span></a></li>-->
                                                    <li><a href="filescontroller.php?action=folderview"><i class="icon-folder-open"></i><span class="hidden-tablet"> File Manager</span></a></li>
                                                    <li><a href="departmentscontroller.php"><i class="icon-folder-open"></i><span class="hidden-tablet"> Departments</span></a></li>
                                                    <li><a href="settings.php"><i class="icon-folder-open"></i><span class="hidden-tablet"> Settings</span></a></li>
                                                    <li><a href="logout.php"><i class="icon-off"></i><span class="hidden-tablet"> Logout</span></a></li>';
					}
					else if(strcmp($_SESSION['user_type'],"Staff Admin")==0)
					{
                                            echo '<li><a href="index.php"><i class="icon-dashboard"></i><span class="hidden-tablet"> Dashboard</span></a></li>
                                                    <li><a href="customerscontroller.php?module=Customers"><i class="icon-briefcase"></i><span class="hidden-tablet"> Customers</span></a></li>
                                                    <li><a href="userscontroller.php?action=Customer_user"><i class="icon-user"></i><span class="hidden-tablet"> Customer Users</span></a></li>
                                                    <!--<li><a href="invoices.html"><i class="icon-file"></i><span class="hidden-tablet"> Invoices</span></a></li>-->
                                                    <li><a href="userscontroller.php"><i class="icon-user"></i><span class="hidden-tablet"> Users</span></a></li>
                                                    <li><a href="paymentscontroller.php"><i class="icon-check"></i><span class="hidden-tablet"> Invoice & Payments</span></a></li>
                                                    <li><a href="servicescontroller.php"><i class="icon-tasks"></i><span class="hidden-tablet"> Services</span></a></li>
                                                    <!--<li><a href="folderscontroller.php"><i class="icon-tasks"></i><span class="hidden-tablet"> Folders</span></a></li>-->
                                                    <li><a href="filescontroller.php?action=folderview"><i class="icon-folder-open"></i><span class="hidden-tablet"> File Manager</span></a></li>
                                                    <li><a href="settings.php"><i class="icon-folder-open"></i><span class="hidden-tablet"> Settings</span></a></li>
                                                    <li><a href="logout.php"><i class="icon-off"></i><span class="hidden-tablet"> Logout</span></a></li>';
					}
					else if(strcmp($_SESSION['user_type'],"Staff")==0)
					{
                                            echo '<li><a href="index.php"><i class="icon-dashboard"></i><span class="hidden-tablet"> Dashboard</span></a></li>
                                                    <li><a href="customerscontroller.php?module=Customers"><i class="icon-briefcase"></i><span class="hidden-tablet"> Customers</span></a></li>
                                                    <li><a href="userscontroller.php?action=Customer_user"><i class="icon-user"></i><span class="hidden-tablet"> Customer Users</span></a></li>
                                                    <!--<li><a href="invoices.html"><i class="icon-file"></i><span class="hidden-tablet"> Invoices</span></a></li>-->
                                                    <li><a href="userscontroller.php"><i class="icon-user"></i><span class="hidden-tablet"> Users</span></a></li>
                                                    <li><a href="paymentscontroller.php"><i class="icon-check"></i><span class="hidden-tablet"> Invoice & Payments</span></a></li>
                                                    <li><a href="servicescontroller.php"><i class="icon-tasks"></i><span class="hidden-tablet"> Services</span></a></li>
                                                    <!--<li><a href="folderscontroller.php"><i class="icon-tasks"></i><span class="hidden-tablet"> Folders</span></a></li>-->
                                                    <li><a href="filescontroller.php?action=folderview"><i class="icon-folder-open"></i><span class="hidden-tablet"> File Manager</span></a></li>
                                                    <li><a href="logout.php"><i class="icon-off"></i><span class="hidden-tablet"> Logout</span></a></li>';
					}
					else if(strcmp($_SESSION['user_type'],"Customer")==0)
					{
						echo '<li><a href="index.php"><i class="icon-dashboard"></i><span class="hidden-tablet"> Dashboard</span></a></li>';
						echo'<li><a href="paymentscontroller.php"><i class="icon-check"></i><span class="hidden-tablet"> Invoice & Payments</span></a></li>
							<li><a href="servicescontroller.php?action=Customer_Service_View"><i class="icon-tasks"></i><span class="hidden-tablet"> Services</span></a></li>
							<li><a href="filescontroller.php"><i class="icon-folder-open"></i><span class="hidden-tablet"> File Manager</span></a></li>
							<li><a href="logout.php"><i class="icon-off"></i><span class="hidden-tablet"> Logout</span></a></li>';
						
					}
					else if(strcmp($_SESSION['user_type'],"Customer Admin")==0)
					{
						echo '<li><a href="index.php"><i class="icon-dashboard"></i><span class="hidden-tablet"> Dashboard</span></a></li>';
						echo '<li><a href="userscontroller.php?action=Customer_user"><i class="icon-user"></i><span class="hidden-tablet"> My Users</span></a></li>
							<li><a href="paymentscontroller.php"><i class="icon-check"></i><span class="hidden-tablet"> Invoice & Payments</span></a></li>
							<li><a href="servicescontroller.php?action=Customer_Service_View"><i class="icon-tasks"></i><span class="hidden-tablet"> Services</span></a></li>
							<li><a href="filescontroller.php"><i class="icon-folder-open"></i><span class="hidden-tablet"> File Manager</span></a></li>
							<li><a href="logout.php"><i class="icon-off"></i><span class="hidden-tablet"> Logout</span></a></li>';
					}
					?>
						
					</ul>
				</div>
			</div>
			<!-- end: Main Menu -->